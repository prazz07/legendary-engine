﻿namespace BethanysPieShop.Utility
{
    public class CacheEntryConstants
    {
        public const string PiesOfTheWeek = "PiesOfTheWeek";
    }
}
