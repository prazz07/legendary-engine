﻿namespace BethanysPieShop.Models
{
    public enum SugarLevel
    {
        Low,
        Medium,
        High
    }
}
