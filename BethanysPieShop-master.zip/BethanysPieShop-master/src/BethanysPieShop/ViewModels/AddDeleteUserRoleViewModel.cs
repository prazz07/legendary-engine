﻿namespace BethanysPieShop.ViewModels
{
    public class AddDeleteUserRoleViewModel
    {
        public string UserId { get; set; }
        public string RoleId { get; set; }

    }
}