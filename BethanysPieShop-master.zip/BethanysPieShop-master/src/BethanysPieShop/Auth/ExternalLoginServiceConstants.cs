﻿namespace BethanysPieShop.Auth
{
    public class ExternalLoginServiceConstants
    {
        public const string GoogleProvider = "Google";
    }
}
