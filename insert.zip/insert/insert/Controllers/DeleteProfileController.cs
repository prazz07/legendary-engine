﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using insert.Models;

namespace insert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeleteProfileController : ControllerBase
    {
        private readonly AppDbContext _context;

        public DeleteProfileController(AppDbContext context)
        {
            _context = context;
        }


        // DELETE: api/DeleteProfile/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<User>> DeleteUser(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return user;
        }

        private bool UserExists(int id)
        {
            return _context.Users.Any(e => e.UserId == id);
        }
    }
}
