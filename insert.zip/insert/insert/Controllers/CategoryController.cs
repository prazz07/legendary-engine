﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using insert.Models;

namespace insert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        //private readonly IUserRepository _userRepository;
        //private readonly ICategoryRepository _categoryRepository;
        //public CategoryController(IUserRepository userRepository, ICategoryRepository categoryRepository)
        //{
        //    _userRepository = userRepository;
        //    _categoryRepository = categoryRepository;

        //}

        private readonly AppDbContext _context;

        public CategoryController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Category
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Category>>> GetCategories()
        {
            return await _context.Categories.ToListAsync();
        }

        // GET: api/Category/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Category>> GetCategory(int id)
        {
            //IEnumerable<User> users;
            //string currentCategory;

            //users = _userRepository.AllUsers.Where(p => p.Category.CategoryId == CategoryId)
            //    .OrderBy(p => p.UserId);
            //currentCategory = _categoryRepository.AllCategories.FirstOrDefault(c => c.CategoryId == CategoryId)?.CategoryName;

            //return users;
            var category = await _context.Categories.FindAsync(id);
            category.Users = _context.Users.Where(c => c.CategoryId == id).ToList();

            if (category == null)
            {
                return NotFound();
            }

            return category; 
        }

        // PUT: api/Category/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategory(int id, Category category)
        {
            if (id != category.CategoryId)
            {
                return BadRequest();
            }

            _context.Entry(category).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CategoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Category
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        //[HttpPost]
        //public async Task<ActionResult<Category>> PostCategory(Category category)
        //{
        //    _context.Categories.Add(category);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction("GetCategory", new { id = category.CategoryId }, category);
        //}

       

        private bool CategoryExists(int id)
        {
            return _context.Categories.Any(e => e.CategoryId == id);
        }
    }
}
