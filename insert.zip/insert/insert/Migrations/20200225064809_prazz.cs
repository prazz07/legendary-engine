﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace insert.Migrations
{
    public partial class prazz : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CategoryName = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "User",
                columns: table => new
                {
                    UserId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(nullable: true),
                    EmailAddress = table.Column<string>(nullable: true),
                    Contact = table.Column<int>(nullable: false),
                    Gender = table.Column<string>(nullable: true),
                    CategoryId = table.Column<int>(nullable: false),
                    ImageUrl = table.Column<string>(nullable: true),
                    ImageThumbnailUrl = table.Column<string>(nullable: true),
                    Bio = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.UserId);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName", "Description" },
                values: new object[,]
                {
                    { 1, "Male", null },
                    { 2, "Female", null },
                    { 3, "Others", null }
                });

            migrationBuilder.InsertData(
                table: "User",
                columns: new[] { "UserId", "Bio", "CategoryId", "Contact", "EmailAddress", "Gender", "ImageThumbnailUrl", "ImageUrl", "UserName" },
                values: new object[,]
                {
                    { 1, "student", 1, 0, null, null, "", "", "Pranjal_Agarwal" },
                    { 2, "student", 2, 0, null, null, "", "", "Riya_Gupta" },
                    { 3, "student", 2, 0, null, null, "", "", "Tanvi_Attreya" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropTable(
                name: "User");
        }
    }
}
