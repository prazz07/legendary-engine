﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace insert.Models
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _appDbContext;

        public UserRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<User> AllUsers
        {
            get
            {
                return _appDbContext.Users.Include(c => c.Category);
            }
        }
       

        public User GetUserById(int userId)
        {
            return _appDbContext.Users.FirstOrDefault(p => p.UserId == userId);
        }
    }
}
