﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace insert.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string EmailAddress { get; set; }
        public int Contact { get; set; }
        public string Gender { get; set; }
        //public string Sexual_Orientation { get; set; }
        public int CategoryId { get; set; }
        public string ImageUrl { get; set; }
        public string ImageThumbnailUrl { get; set; }
        public string Bio { get; set; }      
        public Category Category { get; set; }

    }
}
