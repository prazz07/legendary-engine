﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace insert.Models
{
    public class Category
    {
        public int CategoryId { get; internal set; }
        public string CategoryName { get; set; }
        //public string Description { get; set; }
        public List<User> Users { get; set; }
    }
}
