﻿using System;
using System.Collections.Generic;

namespace CRM_Api
{
    public class Customer
    {
        //private string LastName { get; set; }
        public string FirstName { get; set; }
        public string EmailAddress { get; set; }
        public int CustomerId { get; set; }
    }
}