import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-recipe',
  templateUrl: './select-recipe.component.html',
  styleUrls: ['./select-recipe.component.css']
})
export class SelectRecipeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
